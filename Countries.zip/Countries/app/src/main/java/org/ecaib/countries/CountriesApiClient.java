package org.ecaib.countries;

import android.net.Uri;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;

public class CountriesApiClient {

    String BASE_URL = "https://countriesnow.space/api/v0.1/countries/";

    public ArrayList<Country> getCountriesCapital() {

        Uri builtUri = Uri.parse(BASE_URL)
                .buildUpon()
                .appendPath("capital")
                .build();

        String url = builtUri.toString();
        ArrayList<Country> response = doCall(url);

        return response;
    }

    public String getFlagUrl(String body){

        Uri builtUri = Uri.parse(BASE_URL)
                .buildUpon()
                .appendPath("flag")
                .appendPath("images")
                .build();

        String url = builtUri.toString();
        String response = doCallPost(url, body);
        return response;

    }

    private ArrayList<Country> doCall(String url) {
        try{
            String JsonResponse = HttpUtils.get(url);

            return parseJson(JsonResponse);

        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }

    private String doCallPost(String url, String body) {
        try{
            String response = HttpUtils.post(url, body);

            return response;

        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }

    private ArrayList<Country> parseJson(String jsonResponse) {
        ArrayList<Country> countries = new ArrayList<>();
        try {
            JSONObject cardsResponse = new JSONObject(jsonResponse);
            JSONArray array = cardsResponse.getJSONArray("data");

            for (int i = 0; i < array.length(); i++) {
                Country country = new Country();

                JSONObject object = array.getJSONObject(i);
                country.setName(object.getString("name"));
                country.setCapital(object.getString("capital"));
                country.setIso2(object.getString("iso2"));
                country.setIso3(object.getString("iso3"));

                // Getting the flag image url
                String body = "{\"iso2\":\""+ country.getIso2() + "\"}";
                Log.e("BODY", body);
                String flagUrl = getFlagUrl(body);
                country.setFlagUrl(flagUrl);


                /*
                if (object.has("imageUrl")){
                    country.setImageUrl(object.getString("imageUrl"));
                }

                 */


                countries.add(country);

            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return countries;
    }
}
